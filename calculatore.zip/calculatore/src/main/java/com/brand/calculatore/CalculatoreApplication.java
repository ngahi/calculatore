package com.brand.calculatore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatoreApplication.class, args);
	}

}
